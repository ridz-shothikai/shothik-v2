## Shothik AI — Comprehensive Launch Goal Document

### Overview
Shothik AI is a unified product family combining writing & productivity tools, agentic automation agents, and meta-ads automation. The primary Phase-1 launch goal is to generate awareness and high-quality signups in Asia-first markets (India, Bangladesh, Pakistan, Philippines) while building measurable funnels and validating paid conversion channels for global expansion.

### Mission & Core Goal
- Mission: Empower growth teams, agencies, and creators in APAC to produce and scale high-quality content, research, and ad campaigns faster with agentic automation and easy-to-use writing tools.
- Core launch goal (Phase 1): Capture attention and qualified leads in target APAC markets, validate key value flows (writing workflows + ad campaign automation), and create founder-led momentum (waitlist, founder pricing, early evangelists).

### Product Suite (concise)
- Writing & Productivity: paraphrase, grammar, summarizer, rewrite/humanize, translation, content templates and pricing tiers. (`ROOT\Solutions\Writing & Productivity\writing-productivity-solution.md`)
- Agentic Tools: Deep Research Agent, Slide Generation Agent, Sheet/Excel Automation Agent. (`ROOT\Solutions\Agent\*`)
- Meta Ads Automation (Andromeda): automated creative generation + campaign orchestration; claims in docs must be QA/engineered. (`ROOT\Solutions\Meta Marketing Automation\meta-ads-automation-agent.md`)

### Target Markets & Priority Personas
Priority markets: India (primary), Bangladesh, Pakistan, Philippines (APAC focus), then expand globally.
Priority personas (in order):
1. Growth Marketers / Performance SMEs
2. Content & Operations Leads at small agencies
3. Solo founders / indie makers
4. Students & general writers (secondary; careful with academic claims)

### Phase-1 Objectives (explicit)
- Awareness: Run founder-led channels and organic/social plus targeted performance ads to drive waitlist signups.
- Lead Capture: Build a waitlist with qualification fields to segment Growth Marketer vs. Agency vs. Founder.
- Validate Core Flows: 1) writing task flow (rewrite/summary) 2) campaign flow (creative generation + campaign skeleton).
- Measure: Collect baseline metrics for CPA, activation, and retention within first 14 days.

### KPIs & Acceptance Criteria
- Waitlist signups (Day 14): target number agreed with product team (set X).
- Activation: % of waitlist that completes a core flow within 7 days (target > 20% initially).
- Email performance: Day0 founder mail open rate goal > 30% (industry dependent).
- CPA benchmarking: capture CPA by channel during 14-day tests; compare against target CPA.
- Feature validation: successful QA-run of a campaign creation + a writing task within environment.

### Constraints & Guardrails (must uphold)
- Technical: Frontend is Next.js; backend uses Postgres/Redis and supports Stripe, Razorpay, bKash. Do not make time-based guarantees unless engineering QA confirms them. (`ROOT\Shothik Web\Frontend\SHOTHIK_AI_FRONTEND_ARCHITECTURE.md`, `ROOT\Shothik Web\Executive Summary\SHOTHIK_ARCHITECTURE_BLUEPRINT.md`)
- Legal: Avoid claims that encourage academic cheating or promise Turnitin-proof outputs. Remove or label any plagiarism-circumvention language.
- Marketing: Rephrase any absolute claims (e.g., "URL → Ads in 3 minutes") to conservative, QA-verified phrasing (e.g., "campaigns in minutes — engineering-verify").

### Risks & Mitigations
- Risk: Over-claiming campaign or speed guarantees.
  - Mitigation: Use conservative language and prepend engineering-required flags for time-based claims. Run QA tests to validate.
- Risk: Legal exposure for academic misuse.
  - Mitigation: Explicitly state acceptable uses and include terms of service; route academic/plagiarism concerns to legal.
- Risk: Conflicting TAM / projection numbers across documents.
  - Mitigation: Reconcile with product owner; do not publish conflicting figures.

### Evidence map (key supporting files)
- Writing product features & pricing: `ROOT\Solutions\Writing & Productivity\writing-productivity-solution.md`
- Meta Ads automation (Andromeda): `ROOT\Solutions\Meta Marketing Automation\meta-ads-automation-agent.md`
- Unified ecosystem & projections: `ROOT\Solutions\Executive Summary\shothik-ai-complete-ecosystem.md`
- GTM playbook, funnels, waitlist mechanics: `ROOT\Shothik Web\Executive Summary\SHOTHIK_2_0_GTM_PLAYBOOK_UNIFIED.md`
- Strategic analysis & content gaps: `ROOT\Shothik Web\Executive Summary\SHOTHIK_AI_STRATEGIC_ANALYSIS.md`
- Architecture & payment rails: `ROOT\Shothik Web\Executive Summary\SHOTHIK_ARCHITECTURE_BLUEPRINT.md` and `ROOT\Shothik Web\Frontend\SHOTHIK_AI_FRONTEND_ARCHITECTURE.md`
- Market research & competitor capture: `ROOT\Market\Market Research\competitive-analysis-market-capture.md` and `ROOT\Market\Market Research\EXPANDED_MARKET_RESEARCH_DATASET.md`

### Assumptions (explicit)
- All product features documented exist as minimally viable implementations or prototypes. If not, mark product claims as "experimental".
- Payment integrations (Stripe/Razorpay/bKash) are available for target markets; local currency UX may need further work.
- TAM/SAM numbers will be reconciled before use in investor-facing materials.

### Immediate 14-day Tactical Checklist (practical)
Day 0–2
- Finalize launch messaging and hero copy variants for Growth Marketer & Founder personas. (Use GTM playbook file for templates.)
- Set up waitlist landing page (Next.js) with segmented signup fields and proper UTM tracking. Integrate email provider and baseline analytics.
- Prepare founder email + short founder video script.

Day 3–7
- Run founder email (Day0) and Day3 follow-up with product demo snippets and CTA to try core flow.
- QA-run core flows: a writing rewrite task and a campaign skeleton generation. Time-stamp the flows; record any engineering blockers.
- Start a small paid test (India) targeting Growth Marketers with one hero ad and one landing page variant. Track CPA.

Day 8–14
- Analyze initial funnel metrics (signup → activation). Triage drop-offs and fix top 3 UX issues.
- Iterate ad creative based on initial CTR/engagement. Expand tests to Bangladesh & Pakistan if CPA acceptable.
- Prepare short case study / demo asset from first 10 activated users (with consent) for social proof.

### 30/90 Day Targets (high-level)
- 30 days: Validate product-market fit signals — activation rate, initial paid CPA benchmark, and 2–3 repeatable use-cases.
- 90 days: Grow waitlist, open closed beta for prioritized personas, iterate product delivery & onboarding to increase activation.

### Dependencies & Required Sign-offs
- Engineering sign-off: confirm time-based campaign/automation claims and provide benchmark times for marketing copy.
- Legal sign-off: approve acceptable-use language and anti-abuse policy (academic claims).
- Growth/Product sign-off: confirm KPI targets and budget for paid tests.

### Next steps (who does what)
- Growth lead: finalize founder email, waitlist page, and run Day0 campaign. (Immediate)
- Engineering: perform QA run on campaign AND writing flows and return timing data. (Immediate)
- Legal: draft permissible use language for writing outputs. (Within 7 days)

---

Document prepared from repository sources and validated claims. For specific claim-to-line citations or to convert this into a short `README`/launch checklist page, request the mapping and I will append exact lines/paragraph references from each supporting file.
