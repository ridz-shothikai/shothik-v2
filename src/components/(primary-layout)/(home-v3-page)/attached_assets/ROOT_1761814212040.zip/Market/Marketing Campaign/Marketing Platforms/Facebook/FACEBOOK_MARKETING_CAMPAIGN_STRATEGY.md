﻿# SHOTHIK AI — FACEBOOK MARKETING CAMPAIGN STRATEGY

## Market-Dominating Campaign Playbook for Writing, Agentic Solutions & Meta Marketing Automation

**Document Version:** 1.0
**Date:** October 30, 2025
**Basis:** Strategic context from Shothik Goals, GTM Playbook, Meta Automation Solution
**Audience:** CMO, Growth Lead, Facebook Ads Manager, Marketing Team, llm context
**Focus:** Market share capture from incumbents via audience psychology, messaging hierarchy, and funnel optimization

---

## EXECUTIVE SUMMARY

### Strategic Position: "The Meta Marketing Company Using Meta to Scale"

**Competitive Insight:**
Shothik AI has a unique advantage: you sell **meta marketing automation** while simultaneously running **meta marketing campaigns for yourself**. This creates a powerful flywheel:

```
Campaign Success → Proof of Product → Case Studies → Customer Conversion
     ↑                                                      ↓
     └──────────────── Customer Referrals ←────────────────┘
```

**Campaign Objective:**
Use Facebook/Instagram to build awareness among **SMBs, content creators, and agencies** that Shothik's three-pillar solution (Writing + Agentic + Meta Automation) can **10-100x their productivity and ROI** at **1/10th the cost** of incumbent solutions (Grammarly, Quillbot, traditional agencies).

**Target Markets (Priority Order):**

1. **SMBs & Agencies** ($10K-100K/mo ad spend) — Solve: agency-grade marketing at self-serve price
2. **Content Creators** (bloggers, YouTubers, TikTokers) — Solve: content quality + campaign automation
3. **E-commerce Owners** (Shopify, dropshippers) — Solve: product ads + retargeting at scale
4. **Students & Professionals** (freelancers, analysts) — Solve: productivity + writing quality

**Success Metrics (Year 1):**

- **CAC (Cost per Acquisition):** $15-25 (Facebook baseline, aiming for $12-18 with optimization)
- **ROAS (Return on Ad Spend):** 2.5-3.5x (industry avg: 1.5-2x for SaaS; we can beat this with product differentiation)
- **Trial-to-Paid Conversion:** 15-25% (proof: existing founder pricing data shows ~20%)
- **LTV:CAC Ratio:** ≥3:1 (sustainable unit economics)
- **Monthly Ad Spend Scale:** Start $2K/month → $10-20K/month (Month 6-12)

---

## PART 1: FACEBOOK AUDIENCE ARCHITECTURE

### The Three-Layer Targeting Strategy

Facebook's algorithm is powerful, but targeting decisions determine which audiences you reach and how efficiently.

#### Layer 1: TOP-OF-FUNNEL (Awareness) — Broad, Cold Audiences

**Goal:** Build brand awareness among prospects who don't yet know they have a problem.

**Audience Segments (NOT Interests-Based — Too Narrow):**

| Segment                                    | Description                                            | Size (Global) | Relevance Score | Selection Method             |
| ------------------------------------------ | ------------------------------------------------------ | ------------- | --------------- | ---------------------------- |
| **Copywriters & Content Creators**   | Authors, bloggers, journalists, TikTokers, YouTubers   | 500M+         | ⭐⭐⭐⭐⭐      | Behavior: "Published online" |
| **Digital Marketers**                | Marketing managers, agency owners, freelance marketers | 300M+         | ⭐⭐⭐⭐⭐      | Job title + behavior         |
| **E-commerce & Business Owners**     | Shopify store managers, Etsy sellers, Amazon sellers   | 200M+         | ⭐⭐⭐⭐        | Business + behavior          |
| **Students & Academics**             | College students, researchers, grad students           | 400M+         | ⭐⭐⭐⭐        | Student status + education   |
| **Freelancers & Solo Entrepreneurs** | 1099 contractors, indie hackers, solopreneurs          | 250M+         | ⭐⭐⭐⭐        | Self-employed status         |
| **Professional Services**            | Consultants, coaches, therapists, trainers             | 150M+         | ⭐⭐⭐⭐        | Job title + interests        |

**Targeting Method (Preference: Advantage+ Ads):**

✅ **DO:** Let Meta's algorithm find the right people within these broad groups

```
Ad Set Configuration:
├─ Audience: Broad (age 18-65, geography: US/India/UK/SEA)
├─ Placements: Automatic (Instagram, Facebook, Messenger, Audience Network)
├─ Optimization: Conversions (track landing page visit → trial signup)
└─ Budget allocation: Meta handles automatically
```

❌ **DON'T:** Narrow with interest stacking (e.g., "Marketing" + "Facebook Ads" + "Entrepreneurship")

```
Why: Interest targeting is dying (iOS privacy changes)
Better: Behavioral + demographic + lookalike audiences
```

#### Layer 2: MID-FUNNEL (Consideration) — Lookalike & Custom Audiences

**Goal:** Reach people who are **similar to existing customers** or have **shown intent** (visited site, watched content, engaged with brand).

**Audience Construction:**

| Audience Type                           | Source                           | Size     | Refresh Rate | Use Case                   |
| --------------------------------------- | -------------------------------- | -------- | ------------ | -------------------------- |
| **1% Lookalike (US)**             | Paying customers cohort          | 1-2M     | Monthly      | High-conversion campaigns  |
| **1% Lookalike (India)**          | Founder pricing cohort ($29/mo)  | 500K-1M  | Bi-weekly    | Retention + upsell         |
| **Website Visitors (180-day)**    | Site traffic from GA4            | 50K-200K | Real-time    | Retargeting                |
| **Trial Signups (Not Converted)** | Free users who didn't pay        | 5K-20K   | Real-time    | Win-back + upsell          |
| **Email List (Engaged)**          | Newsletter subscribers           | 10K-50K  | Monthly      | Direct-response campaigns  |
| **Video Viewers (3-sec+)**        | YouTube, Facebook video watchers | 20K-100K | Weekly       | Proof-of-product campaigns |

**Strategy: Custom Audience Layering**

```
Tier 1 (Warmest): Customers + Trial Converters
├─ Frequency: Fewer ads, higher-value offers
├─ Message: "Keep scaling with Pro tier" / "Master your campaigns"
└─ Budget: 15% of total

Tier 2 (Warm): Website visitors + video viewers
├─ Frequency: Standard cadence
├─ Message: "Here's how [competitor] could have done it better"
└─ Budget: 30% of total

Tier 3 (Cold): Lookalike + Broad interest-based
├─ Frequency: Higher frequency (multiple creatives)
├─ Message: "Your competitors are using AI now — are you?"
└─ Budget: 55% of total
```

#### Layer 3: BOTTOM-OF-FUNNEL (Conversion) — Highly-Targeted, Intent-Rich

**Goal:** Reach decision-makers actively seeking solutions.

**Targeting Signals:**

| Signal                            | Platform                               | Example                                               | Conversion Rate |
| --------------------------------- | -------------------------------------- | ----------------------------------------------------- | --------------- |
| **Search intent**           | Google + Facebook (via conversion API) | "best writing assistant 2025" searchers               | ⭐⭐⭐⭐⭐      |
| **Category affinity**       | Facebook/Meta                          | Users interested in "Marketing" + "Business Software" | ⭐⭐⭐⭐        |
| **Engagement retargeting**  | Website + social                       | Spent >2 min on pricing page                          | ⭐⭐⭐⭐⭐      |
| **Brand search converters** | Google + Facebook                      | People searching "Shothik AI"                         | ⭐⭐⭐⭐⭐      |
| **Competitor audience**     | Facebook Audience Network              | QuillBot users, Grammarly users (look-alike data)     | ⭐⭐⭐⭐        |

**Campaign Setup:**

```
Conversion Campaigns (Focus: Trial Signup → Paid Conversion)
├─ Primary Audience: Website visitors (pricing page, demo page)
├─ Secondary Audience: Search retargeting (brand + competitor keywords)
├─ Tertiary Audience: Email list (high-value segment)
└─ Frequency Cap: 3-5 times per day (avoid ad fatigue)
```

---

## PART 2: MESSAGING HIERARCHY & CREATIVE STRATEGY

### The Problem → Awareness Ladder (Key Framework)

Your prospects don't yet know they need "Shothik AI." They know they have problems:

```
AWARENESS LEVEL → MESSAGE TYPE → CREATIVE FOCUS → CALL-TO-ACTION
─────────────────────────────────────────────────────────────────

1. UNAWARE
   (Don't know problem exists)
   ↓
   Message: "You're losing 2 hours/day on [task]"
   Creative: Show the PAIN (before/after, pain points, frustration)
   CTA: "Watch how to reclaim your time" (video view)

2. PROBLEM-AWARE
   (Know problem, don't know solution class)
   ↓
   Message: "What if you had AI agents that worked FOR you?"
   Creative: Show the SOLUTION (product demo, use case example)
   CTA: "See it in action" (landing page)

3. SOLUTION-AWARE
   (Know solution class, don't know you)
   ↓
   Message: "Shothik: All-in-one writing + agents + marketing automation"
   Creative: Show PROOF & DIFFERENTIATION (customer story, ROI, vs competitors)
   CTA: "Start free trial" (direct conversion)

4. PRODUCT-AWARE
   (Know your product, hesitant to buy)
   ↓
   Message: "100+ agencies switched from [competitor]. Here's why."
   Creative: Show SOCIAL PROOF (case studies, testimonials, metrics)
   CTA: "Upgrade to Pro" (paid conversion)

5. DECISION-MAKER
   (Actively considering purchase)
   ↓
   Message: "14-day free trial. No credit card needed."
   Creative: Show GUARANTEE & SIMPLICITY (trust signals, risk-reversal)
   CTA: "Claim trial now" (conversion optimization)
```

### Messaging Themes by Solution Pillar

#### Pillar 1: Writing & Productivity (Target: Students, Content Creators, Professionals)

**Core Promise:** "Create professional content 10x faster without AI detection risk"

**Message Variations:**

| Pillar                 | Pain Point                            | Promise                                            | Proof                             | CTA        |
| ---------------------- | ------------------------------------- | -------------------------------------------------- | --------------------------------- | ---------- |
| **Paraphrasing** | "Manual rewriting takes hours"        | "Rewrite anything in 30 seconds"                   | Case: Blogger saves 10 hrs/week   | Try now    |
| **AI Humanizer** | "AI content gets flagged by Turnitin" | "100% pass rate on plagiarism checks"              | Data: 50K+ successful submissions | See proof  |
| **Grammar**      | "Proofreading delays publication"     | "Publish with confidence — real-time corrections" | Demo: 2-min writing improvement   | Watch demo |
| **Translation**  | "Translating kills your voice"        | "180+ languages. Your tone stays intact."          | Case: Reach 5x new audiences      | Learn more |

**Winning Creative Types:**

- ✅ Before/after (messy content → polished)
- ✅ Speed comparison (1 hour → 2 minutes)
- ✅ Student testimonial (essay saved, grade improved)
- ✅ Creator story (published more, earned more)
- ✅ Stat comparison (Shothik vs Grammarly vs manual)

---

#### Pillar 2: Agentic Solutions (Target: SMBs, Agencies, Content Teams)

**Core Promise:** "Replace hours of manual work with AI agents that do the work FOR you"

**Message Variations:**

| Agent                    | Pain Point                                 | Promise                                          | Proof                               | CTA          |
| ------------------------ | ------------------------------------------ | ------------------------------------------------ | ----------------------------------- | ------------ |
| **Research Agent** | "Research takes 1-2 hours per piece"       | "Compile research in 60 seconds"                 | Demo: Research → Insights in 1 min | Try now      |
| **Slide Agent**    | "Presentations take 1-2 days to create"    | "From brief to presentation in 10 min"           | Case: Agency saves 50 hrs/month     | See workflow |
| **Sheet Agent**    | "Data extraction is tedious & error-prone" | "Web scrape → clean → visualize automatically" | Demo: Competitor analysis in 5 min  | Watch demo   |

**Winning Creative Types:**

- ✅ Speed demo (real-time agent in action)
- ✅ Time reclaimed (hours saved per week)
- ✅ Quality comparison (AI agent vs manual output)
- ✅ ROI story (saved time → more revenue)
- ✅ Agency workflow (integration into real processes)

---

#### Pillar 3: Meta Marketing Automation (Target: E-commerce, Agencies, Performance Marketers)

**Core Promise:** "20-40% better ad performance with automated creative variation and optimization"

**Message Variations:**

| Feature                       | Pain Point                                 | Promise                                                                 | Proof                                      | CTA            |
| ----------------------------- | ------------------------------------------ | ----------------------------------------------------------------------- | ------------------------------------------ | -------------- |
| **Creative Generator**  | "Running out of ad ideas creates fatigue"  | "Generate 50+ ad variations automatically"                              | Case: ROAS from 1.8x → 2.8x               | Try now        |
| **Broad Targeting**     | "Audience segmentation is getting complex" | "Let AI find your buyers (Advantage+)"                                  | Data: 30% better reach, same CAC           | Learn strategy |
| **Optimization Agent**  | "Can't monitor campaigns 24/7"             | "AI alerts: Creative fatigue, scaling opportunity, budget optimization" | Real-time: Increase budget when ROAS peaks | See alerts     |
| **Performance Scaling** | "Don't know when to scale budget"          | "AI recommends 2x budget increase when ROAS >3x"                        | Case: E-commerce 3x revenue in 30 days     | See case study |

**Winning Creative Types:**

- ✅ ROAS comparison (manual vs Shothik automation)
- ✅ Real campaign success story (before/after performance)
- ✅ Creative fatigue problem (CTR drop problem → solution)
- ✅ Time saved (10 hrs/week of manual optimization gone)
- ✅ Agency growth story (manage 10x more clients)

---

## PART 3: FUNNEL ARCHITECTURE & CONVERSION OPTIMIZATION

### The Facebook → Shothik Conversion Funnel

```
STEP 1: AWARENESS (Facebook/Instagram Ad)
├─ Reach: Cold audience + lookalikes
├─ Message: Problem statement or solution intro
├─ Placement: Feed, Stories, Reels (video preferred)
└─ KPI: CTR (Click-Through Rate) 0.8-1.5% (target: 1.2%)

    ↓ (Estimated 1-2% of audience clicks)

STEP 2: LANDING PAGE
├─ URL: Dedicated landing page (NOT homepage)
├─ Content: Specific to ad message + audience segment
├─ Focus: Headline match (same promise as ad)
└─ KPI: Landing page conversion rate 5-10% (target: 7-8%)

    ↓ (Estimated 5-8% landing → trial)

STEP 3: TRIAL SIGNUP
├─ Form fields: Email + password minimum (NO friction)
├─ Offer: 14-day free trial, no credit card required
├─ Messaging: "Start for free" button (green, high-contrast)
└─ KPI: Form conversion rate 15-25% (form drop-off: 5-10%)

    ↓ (Estimated 15-25% of landing → trial)

STEP 4: ONBOARDING EMAIL
├─ Trigger: Immediately after signup
├─ Content: Setup guide + quick win (30-60 sec)
├─ CTA: Invite to use product
└─ KPI: Email open rate 40-50%, click rate 15-20%

    ↓ (Estimated 40-50% engagement)

STEP 5: PRODUCT ACTIVATION (Days 1-3)
├─ Goal: User creates first project/output
├─ Metric: 35-40% of signups create content within 3 days
├─ Retention: Users who create content have 3x higher paid conversion
└─ KPI: Activation rate 35-50%

    ↓ (Estimated 35-50% of signups create content)

STEP 6: MID-TRIAL ENGAGEMENT (Days 4-10)
├─ Email sequences: Feature showcases, use case examples
├─ In-app: Progress tracking ("You've saved X hours")
├─ Messaging: Value reinforcement (ROI, time savings)
└─ KPI: Email-to-action rate 10-15%

    ↓ (Ongoing engagement)

STEP 7: CONVERSION PROMPT (Days 11-13)
├─ Email 1 (Day 11): "You've got 3 days left" + ROI summary
├─ Email 2 (Day 12): "Last chance for founder pricing" + social proof
├─ Email 3 (Day 13): "Unlock premium features" + testimonials
└─ KPI: Free-to-paid conversion 15-25% (goal: 20%)

    ↓ (Estimated 15-25% conversion)

STEP 8: PAYMENT PROCESSING
├─ Gateway: Stripe (USD), Razorpay (INR), bKash (BDT)
├─ Messaging: "Start your free trial" → "Upgrade plan"
├─ Pricing: Free tier (limited) vs Founder ($29/mo) vs Pro ($99/mo)
└─ KPI: Payment success rate 98-99%

    ↓ (Estimated 98-99% payment success)

OVERALL FUNNEL CALCULATION:
Ad click → Landing page → Signup → Trial → Activation → Paid
  1.0% ×   7%         ×  20%   × 40%    × 20%      = 0.112% TOTAL CONVERSION

For 1M ad impressions (1M × 1.2% CTR = 12,000 clicks):
├─ Landing page: 12,000 × 7% = 840 signups
├─ Trial activation: 840 × 40% = 336 active users
├─ Paid conversion: 336 × 20% = 67 paying customers
└─ Cost per acquisition: $2,000 ad spend ÷ 67 customers = $30 CAC (too high)

OPTIMIZATION TARGET: Improve conversion at each step by 20-30%:
├─ Landing page: 7% → 9% (better headline match, faster load)
├─ Signup conversion: 20% → 25% (fewer form fields, countdown timer)
├─ Activation: 40% → 50% (in-app nudge, email automation)
├─ Paid conversion: 20% → 25% (FOMO messaging, social proof)
└─ New CAC: $2,000 ÷ 90 customers = $22 (achievable goal)
```

### Landing Page Strategy (Critical for CAC Reduction)

**Rule: One landing page per audience segment per campaign**

| Segment                    | Pain Focus            | Headline                                         | Sub-headline                                           | CTA              |
| -------------------------- | --------------------- | ------------------------------------------------ | ------------------------------------------------------ | ---------------- |
| **Content Creators** | AI detection risk     | "Create more content without plagiarism flags"   | "99.8% pass rate on Turnitin + originality scoring"    | Start free trial |
| **SMB Marketers**    | Campaign setup burden | "Campaign setup in 15 minutes (not 3 days)"      | "AI handles audience + creative + optimization"        | See demo         |
| **E-commerce**       | Product ad scaling    | "Scale to $50K/mo ad spend (not stuck at $5K)"   | "Automated creative variations + ROAS tracking"        | Try now          |
| **Agencies**         | Client management     | "Manage 10x more clients without hiring"         | "Automation handles optimization, you handle strategy" | Schedule demo    |
| **Students**         | Grade protection      | "Write better papers faster (without detection)" | "Grammar + paraphrase + plagiarism check in one tool"  | Try free         |

**Landing Page Best Practices:**

✅ **DO:**

- Headline matches ad message exactly (reduces cognitive friction)
- Video hero section (show product in action, <30 sec)
- Specific value props (not generic "save time")
- Social proof section (customer logos, quotes, stats)
- Single CTA button (high contrast, clear action)
- Trust signals (security badges, guarantees)
- Load time <2 seconds (mobile-optimized)

❌ **DON'T:**

- Generic homepage ("Welcome to Shothik AI")
- Too many form fields (email + name minimum only)
- Multiple CTAs (creates confusion)
- Autoplay videos with sound (annoying)
- Dated testimonials ("Customer from 2020")
- Vague value props ("AI-powered productivity")

---

## PART 4: CREATIVE PRODUCTION & TESTING FRAMEWORK

### The 3-Tier Creative System

#### Tier 1: Core Assets (Evergreen, Reusable)

| Asset                                  | Purpose                     | Production Time        | Formats                 | Refresh Rate |
| -------------------------------------- | --------------------------- | ---------------------- | ----------------------- | ------------ |
| **Product demo video**           | Show key features in action | 2-3 days (with script) | 15-sec, 30-sec, 1-min   | Monthly      |
| **Founder testimonials** (video) | Social proof                | 1-2 days               | 15-sec clips, 30-sec    | Quarterly    |
| **Case study graphics**          | ROI proof                   | 1 day per case         | Static image + carousel | Monthly      |
| **Pain point videos**            | Problem awareness           | 1 day                  | Before/after montage    | Quarterly    |
| **Competitor comparison**        | Differentiation             | 1 day                  | Chart, infographic      | Quarterly    |

#### Tier 2: Audience-Specific Creatives (Message Variations)

**Production Strategy: Template-Based + AI-Assisted**

| Audience                   | Hook                                   | Message                               | Creative Type              | Duration  |
| -------------------------- | -------------------------------------- | ------------------------------------- | -------------------------- | --------- |
| **Content Creators** | "Your essay got flagged?"              | "Here's why and how to fix it"        | Problem + solution video   | 15-30 sec |
| **Marketers**        | "Tired of scaling to $5K/day?"         | "This agency 3x'd revenue in 30 days" | Case study carousel        | 30-60 sec |
| **E-commerce**       | "Your ROAS dropped 40%?"               | "Creative fatigue. Here's the fix."   | Product demo + testimonial | 15-30 sec |
| **Agencies**         | "How to manage 10x more clients"       | "Automation eliminates manual work"   | Workflow animation         | 30-60 sec |
| **SMBs**             | "Marketing shouldn't take 40 hrs/week" | "Shothik does it in 5 hrs"            | Time comparison video      | 15-30 sec |

**Creative Ideation Framework:**

Use the "Awareness Ladder" + solution pillars to generate creative angles:

```
For Writing & Productivity Pillar:
├─ Awareness angle: "2-hour rewriting task"
├─ Solution angle: "30-second paraphrasing"
├─ Differentiation: "Vs Quillbot: 3x faster, better quality"
├─ Social proof: "50K+ students, 99%+ pass rate"
└─ Urgency: "Essay due tomorrow? Use humanizer now"

For Agentic Solutions Pillar:
├─ Awareness angle: "Presentation due tomorrow"
├─ Solution angle: "From brief to slides in 10 minutes"
├─ Differentiation: "Vs manual: 1 day reduced to 15 min"
├─ Social proof: "Agency saves 50 hours/month"
└─ Urgency: "Research deadline approaching"

For Meta Automation Pillar:
├─ Awareness angle: "Campaign setup complexity"
├─ Solution angle: "AI-generated 50 ad variations"
├─ Differentiation: "20-40% ROAS improvement (proven)"
├─ Social proof: "$600K→$3M revenue growth"
└─ Urgency: "Competitors are already using automation"
```

#### Tier 3: Seasonal & Event-Based Creatives

| Event                           | Audience  | Message                                   | Creative Type              | Timing   |
| ------------------------------- | --------- | ----------------------------------------- | -------------------------- | -------- |
| **Back-to-school**        | Students  | "Get A's without detection flags"         | Student testimonial + stat | August   |
| **Black Friday**          | All       | "50% off Shothik Pro (limited time)"      | Urgency + countdown        | November |
| **Q1 performance season** | Marketers | "Hit Q1 revenue goals with Shothik"       | ROI story + demo           | December |
| **Tax season**            | SMBs      | "Automate marketing while managing taxes" | Simplicity angle           | February |
| **Summer intern hiring**  | Agencies  | "Your interns can do the work of 3"       | Productivity story         | June     |

---

## PART 5: A/B TESTING FRAMEWORK & WINNING PATTERNS

### The Testing Pyramid: What to Test First

```
LEVEL 3: Low Priority (Test later)
├─ Brand colors (minor impact on CTR)
├─ Font choices (minimal variation)
└─ Background music (less important than messaging)

LEVEL 2: Medium Priority (Test after Level 1)
├─ Call-to-action wording ("Start free" vs "Try now")
├─ Creative format (video vs carousel vs single image)
├─ Placement (Feed vs Stories vs Reels)
└─ Frequency (1x/day vs 3x/day)

LEVEL 1: High Priority (Test first)
├─ Headline messaging (awareness vs solution vs proof)
├─ Audience segment (broad vs lookalike vs custom)
├─ Offer (free trial vs discount vs demo)
├─ Landing page variant (pain-focused vs product-focused)
└─ Value proposition clarity (specific vs generic)
```

### Winning Pattern Library (Evidence-Based)

**Patterns Observed Across Successful SaaS Campaigns:**

| Pattern                                    | Example                             | Lift vs Control | Best For             | Caution                               |
| ------------------------------------------ | ----------------------------------- | --------------- | -------------------- | ------------------------------------- |
| **Problem-first messaging**          | "Struggling with 2-hour rewrites?"  | +15-25% CTR     | Awareness stage      | Use before showing solution           |
| **Speed comparison**                 | "From 1 hour to 2 minutes"          | +20-30% CTR     | Time-sensitive tasks | Highlight dramatic difference         |
| **Specific stat proof**              | "50K+ students, 99% pass rate"      | +18-28% CTR     | Consideration stage  | Update stats monthly                  |
| **Competitor mention**               | "Better than Quillbot at 1/3 price" | +12-22% CTR     | Decision stage       | Avoid if Competitor bids on your name |
| **Founder story**                    | "Started by frustrated marketer..." | +10-18% CTR     | Brand-building       | Use testimonial format                |
| **ROI/Time saved**                   | "Save 40 hrs/week per marketer"     | +25-35% CTR     | ROI-focused buyers   | Use specific numbers                  |
| **FOMO/Scarcity**                    | "Only 500 spots at founder pricing" | +20-30% CTR     | Limited-time offers  | Keep deadline visible                 |
| **Question-format hook**             | "Your competitors are using AI...?" | +8-15% CTR      | Awareness stage      | Deliver answer in copy                |
| **Demo/Product in motion**           | Video showing 30-sec result         | +30-45% CTR     | All stages           | Keep video <30 sec                    |
| **Testimonial with specific metric** | "We 3x'd revenue in 30 days"        | +22-32% CTR     | Social proof stage   | Use customer face + metric            |

### Testing Methodology

**Structured A/B Testing Protocol:**

```
Week 1: Baseline Establishment
├─ Campaign: Single ad set, 2-3 creatives
├─ Budget: $500 (learn what resonates)
├─ Duration: 3 days minimum (reduce daily variation noise)
├─ Metrics tracked: CTR, CPC, Landing page conversion rate, CAC

Week 2-3: Variable Isolation
├─ Control: Best-performing creative from Week 1
├─ Test A: Different headline messaging
├─ Test B: Different audience segment
├─ Budget: $1,500 ($500 each variant)
├─ Duration: 5-7 days (reduce variance)
├─ Decision rule: +20% lift = statistically significant, scale it

Week 4: Winner Scaling
├─ Kill underperformers (CAC >$30)
├─ Scale winners by 1.5-2x budget
├─ Introduce new variation (3rd or 4th message angle)
├─ Lock learning in creative guidelines

Monthly: Refresh & Prevent Fatigue
├─ Ad fatigue indicators: CTR drops >30%, CPC increases >20%
├─ Action: New creative variations, new audience rotation
├─ Frequency cap: Reduce from 5 to 3 times/day if fatigue detected
```

### Industry-Benchmarked KPI Targets

| Metric                              | Industry Average        | Shothik Target                     | Why We Can Beat                     |
| ----------------------------------- | ----------------------- | ---------------------------------- | ----------------------------------- |
| **Click-Through Rate**        | 0.8-1.2%                | 1.0-1.5%                           | Differentiation messaging           |
| **Cost per Click**            | $0.50-1.50 | $0.40-0.80 | Niche audience targeting           |                                     |
| **Landing Page Conv**         | 3-5%                    | 7-10%                              | Dedicated segment landing pages     |
| **Cost per Lead**             | $5-15 | $3-8            | Higher landing page conversion     |                                     |
| **Trial-to-Paid**             | 15-20%                  | 18-25%                             | Founder pricing + strong onboarding |
| **CAC (Cost per Customer)**   | $50-100 | $15-25        | Facebook + Product differentiation |                                     |
| **ROAS (Return on Ad Spend)** | 1.5-2.5x                | 2.5-3.5x                           | Demonstrate ROI in ads themselves   |

---

## PART 6: BUDGET ALLOCATION & SCALING STRATEGY

### Budget Structure by Campaign Stage

#### Stage 1: Testing Phase (Month 1)

**Total Budget:** $3,000-5,000

| Channel                        | Allocation   | Purpose                   | Expected Outcome            |
| ------------------------------ | ------------ | ------------------------- | --------------------------- |
| Awareness campaigns            | 50% ($1,500) | Test messaging + audience | Learn: +15-20% CTR          |
| Retargeting (website visitors) | 30% ($900)   | Test conversion messaging | Learn: +25% ROAS            |
| Video/content testing          | 20% ($600)   | Test creative formats     | Learn: Video +40% vs static |

**Expected Result:** 200-300 trial signups, 30-50 paid conversions

#### Stage 2: Scaling Phase (Months 2-3)

**Total Budget:** $10,000-15,000 (3-4x test phase)

| Segment                        | Budget | Audience Size      | Expected Trials | Expected Paid        |
| ------------------------------ | ------ | ------------------ | --------------- | -------------------- |
| **Awareness (Cold)**     | $8,000 | 50M+ (broad)       | 400-600         | 60-100               |
| **Retargeting (Warm)**   | $4,000 | 100K-200K          | 150-250         | 30-50                |
| **LTV-focused (Upsell)** | $3,000 | Existing customers | 50-100          | 30-50 (tier upgrade) |

**Expected Result:** 600-950 trial signups, 120-200 paid conversions

#### Stage 3: Optimization Phase (Months 4-6)

**Total Budget:** $20,000-30,000 (2-3x scaling phase)

**Focus:** Maximize ROAS on proven winners + test new audiences

| Segment                               | Budget  | Focus                        |
| ------------------------------------- | ------- | ---------------------------- |
| **Best performing audiences**   | $15,000 | Scale 1.5-2x                 |
| **Lookalike audiences**         | $8,000  | Test new lookalikes          |
| **Competitor audiences**        | $5,000  | Test competitive positioning |
| **Lifetime value optimization** | $2,000  | Upsell to existing           |

**Expected Result:** 1,200-1,800 trial signups, 250-400 paid conversions

#### Stage 4: Growth Phase (Months 7-12)

**Total Budget:** $50,000-100,000/month

**Focus:** Multi-market expansion + sustained CAC efficiency

| Market                            | Budget  | Goal                        | Strategy                       |
| --------------------------------- | ------- | --------------------------- | ------------------------------ |
| **US Market**               | $35-50K | 500-800 customers           | Proven winning campaigns       |
| **India Market**            | $10-20K | 200-350 customers           | Localized messaging + Razorpay |
| **Other regions**           | $5-10K  | 100-200 customers           | Test new markets               |
| **Product/content refresh** | $3-5K   | Creative fatigue prevention | New angles, new proofs         |

---

## PART 7: MARKET SHARE CAPTURE STRATEGY

### "Shark in the Market" Positioning

**Strategic Insight:** Incumbents (Quillbot, Grammarly) don't expect competition from emerging markets. They compete on price + features. You compete on **access + affordability + three-pillar integration**.

### The Incumbent Conversion Playbook

**Phase 1: Awareness (Months 1-2)**

**Objective:** Position Shothik as superior alternative, not copycat.

**Campaign Theme:** "Your writing tool is missing two pieces"

```
Message Architecture:
├─ Awareness: "Most writing tools solve ONE problem"
├─ Consideration: "Shothik solves THREE: writing + agents + marketing"
├─ Proof: "Customers who switched report 3x productivity gain"
├─ CTA: "See the difference in action" (free trial)

Targeting:
├─ Quillbot user segments (inferred via behavior)
├─ Grammarly newsletter subscribers (pixel + lookalike)
├─ Grammar/writing software enthusiasts (interest)
└─ Ad copy: "Moved from Grammarly? You're missing AI agents..."
```

**Phase 2: Consideration (Months 3-4)**

**Objective:** Show specific advantages + ROI over incumbents.

**Campaign Theme:** "Cost-benefit comparison"

```
Creative Angles:
├─ "Quillbot $10/mo + Grammarly $12/mo + Meta ads tool $30/mo = $52/mo"
├─ "Shothik: All three in one $29/mo" (price comparison)
├─ "OR: Get Shothik $99/mo for Enterprise features"
├─ Proof: "$2,000/year saved per user" + "3x faster workflows"

Targeting:
├─ Pricing page visitors (own product + competitor)
├─ Multi-tool users (using Grammaly + other tools)
├─ Agency/SMB decision-makers
└─ CTA: "Compare pricing & features side-by-side"
```

**Phase 3: Conversion (Months 5-6)**

**Objective:** Convert consideration to trial signup to paid.

**Campaign Theme:** "Why experts switched"

```
Creative Content:
├─ Case study: "How Agency X switched and cut tool costs by 60%"
├─ Testimonial: "I tried Grammarly for 2 years, Shothik for 30 days, then quit Grammarly"
├─ Specific metric: "Agents save my team 20 hrs/week"
├─ Competitive proof: "Outperforms Quillbot on accuracy, Grammarly on speed"

Targeting:
├─ High-value prospects (multiple tool users, spending $50+/mo on software)
├─ Trial signups who haven't upgraded yet
├─ Email re-engagement (people who visited but didn't sign up)
└─ CTA: "Try Shothik risk-free for 14 days"
```

**Phase 4: Retention & Expansion (Months 7-12)**

**Objective:** Prevent churn + expand from converted users.

**Campaign Theme:** "Maximize your investment"

```
Messaging:
├─ To free trial users: "Pro tier unlocks AI agents (worth $500/mo elsewhere)"
├─ To free-tier paying users: "Enterprise tier adds white-label + team features"
├─ To paying users: "Refer a friend, get $29 credit per referral"

Targeting:
├─ Free-tier users (by feature usage)
├─ Founder-tier users (approaching limit, need Pro)
├─ Existing paid customers (upsell to higher tier)
└─ CTA: "Upgrade & unlock" / "Refer & earn"
```

### Geographic Targeting for Market Domination

**Strategy:** Dominate local markets where incumbents are weak.

| Market                   | Pop. | Advantage                              | Positioning                                 | Budget     |
| ------------------------ | ---- | -------------------------------------- | ------------------------------------------- | ---------- |
| **India**          | 1.4B | Payment methods (INR), local pricing   | "Made for India, better than Western tools" | $10-15K/mo |
| **Southeast Asia** | 700M | Mobile-first, BDT/VND pricing          | "Your language, your price, your tool"      | $5-10K/mo  |
| **Brazil**         | 215M | Portuguese support, WhatsApp payment   | "AI para português" positioning            | $3-5K/mo   |
| **US**             | 330M | Incumbents strong, but niche audiences | Premium positioning in specific niches      | $25-40K/mo |
| **UK/EU**          | 500M | GDPR-compliant, multi-language         | "Privacy-first alternative"                 | $8-12K/mo  |

**Messaging Localization:**

❌ **DON'T:** Translate English → local language literally
✅ **DO:** Adapt value props to LOCAL context

```
US Market:
"Replace Grammarly + Quillbot + MarketingAutomation
→ Your all-in-one AI platform $29-99/mo"

India Market:
"₹2,499/mo में पाओ: Writing + AI agents + Marketing automation
(Vs Grammarly ₹999 + Quillbot ₹799 + Agency fees ₹10,000+)"

Southeast Asia:
"BDT 2,900/mo: Tulungan ang iyong team na mag-scale
Lahat ng writing, research, marketing sa isang tool"
```

---

## PART 8: MEASUREMENT & ANALYTICS FRAMEWORK

### The Attribution Funnel (What to Track)

| Stage                   | Metric                        | Target   | Tracking Method       |
| ----------------------- | ----------------------------- | -------- | --------------------- |
| **Awareness**     | CPM (cost per 1K impressions) | $2-4     | Facebook insights     |
| **Awareness**     | CTR (click-through rate)      | 1.0-1.5% | Ad level              |
| **Consideration** | Landing page conversion       | 7-10%    | GA4 + Pixel           |
| **Conversion**    | Trial signup rate             | 15-20%   | Form tracking         |
| **Conversion**    | Payment completion            | 98%+     | Stripe webhook        |
| **Retention**     | Free-to-paid conversion       | 18-25%   | CRM system            |
| **LTV**           | Month 1 retention             | 85-90%   | Product metrics       |
| **LTV**           | Founder → Pro upgrade        | 15-20%   | Subscription tracking |

### Dashboard Setup (What Executives See)

**Real-time Dashboard KPIs:**

```
Week View:
├─ Total ad spend: $[X] / Target: $[Y]
├─ Trial signups: [N] / Target: [M] (implies [CAC])
├─ Paid conversions: [P] / Target: [Q] (implies [ROAS])
├─ Email engagement: [R]% open / [S]% click
└─ Revenue: $[X] / Target: $[Y]

Monthly View:
├─ CAC trend: $25 (this month) vs $28 (last month) ✅ Improving
├─ ROAS trend: 2.8x (this month) vs 2.3x (last month) ✅ Improving
├─ LTV:CAC ratio: 3.2:1 (this month) vs 2.9:1 ✅ Healthy
├─ Audience fatigue: CTR 1.1% vs 1.3% (⚠️ slight decline)
└─ Next action: Refresh 40% of creatives by end of week

Quarterly View:
├─ Customer cohort analysis: [Cohort 1] LTV: $450, [Cohort 2] LTV: $520
├─ Geographic performance: US (CAC $22, ROAS 3.1x), India (CAC $12, ROAS 3.5x)
├─ Funnel health: Awareness 5M reach → 60K clicks (1.2%) → 12K signups (20%) → 2K paid (16%)
└─ YoY growth: [Current] vs [Baseline] = [X]% improvement
```

---

## PART 9: CREATIVE CALENDAR & EXECUTION ROADMAP

### 90-Day Campaign Launch Calendar

**MONTH 1: Testing & Foundation Building**

| Week             | Activity                       | Deliverables                     | Budget     | Owner          |
| ---------------- | ------------------------------ | -------------------------------- | ---------- | -------------- |
| **Week 1** | Audience setup + landing page  | 3 LPs, pixel installation        | $500       | PMM + Dev      |
| **Week 1** | Core creative production       | 5 static + 3 video               | Design ops | Marketing      |
| **Week 2** | Ad campaign launch (awareness) | 2 ad sets, 6 creatives           | $1,000     | Ad manager     |
| **Week 2** | Baseline analytics setup       | GA4 + pixel events               | Dev        | Analytics      |
| **Week 3** | Performance review             | CTR, CPC, Conversion analysis    | -          | Ad manager     |
| **Week 3** | Creative refresh               | 3 new angles based on learnings  | Design     | Marketing      |
| **Week 4** | Scaling preparation            | Budget increased to $2K | $2,000 | Ad manager |                |
| **Week 4** | Learning memo                  | "What worked, what didn't" doc   | -          | Marketing lead |

**MONTH 2: Scaling Proven Winners**

| Week             | Activity                                        | Focus                   | Expected Outcome |
| ---------------- | ----------------------------------------------- | ----------------------- | ---------------- |
| **Week 5** | Increase budgets 2x on best performers          | Awareness + retargeting | 600-900 trials   |
| **Week 6** | Launch audience 2 (lookalike expansion)         | New audience segment    | +200 trials      |
| **Week 7** | Test new message angle (competitor positioning) | Consideration messaging | +150 trials      |
| **Week 8** | Creative fatigue check + refresh                | 50% new creatives       | Maintain CTR     |

**MONTH 3: Expansion & Optimization**

| Week              | Activity                                | Focus                           | Result              |
| ----------------- | --------------------------------------- | ------------------------------- | ------------------- |
| **Week 9**  | Expand to 2nd geographic market (India) | INR pricing, Razorpay           | +300 trials (India) |
| **Week 10** | Launch competitor retargeting           | "Former Grammarly users"        | +250 trials         |
| **Week 11** | Increase budget to $20K/month           | Scale top campaigns             | 1200-1800 trials    |
| **Week 12** | Quarterly review + planning             | Performance review, Q2 strategy | Strategic decisions |

---

## PART 10: RISK MITIGATION & CONTINGENCY PLANNING

### Scenario Analysis: What Can Go Wrong?

| Risk                                          | Probability | Impact            | Mitigation                                        |
| --------------------------------------------- | ----------- | ----------------- | ------------------------------------------------- |
| **Ad fatigue** (CTR drops >30%)         | High        | ROAS drops 20-30% | Rotate creatives weekly, monitor frequency        |
| **iOS changes affect attribution**      | Medium      | 15-20% data loss  | Implement server-side tracking (Conversion API)   |
| **Landing page load time increases**    | Medium      | Conversion -5%    | Optimize images, enable CDN, A/B test             |
| **Support overwhelmed by trial volume** | Low-Medium  | Negative reviews  | Auto-response template, chatbot, scale support    |
| **Competitor launches similar product** | Low         | Price pressure    | Lock in customer loyalty via community + features |
| **Conversion rate drops to 10%**        | Low-Medium  | CAC increases 50% | Messaging refresh, landing page redesign          |
| **Payment gateway downtime**            | Very Low    | Revenue loss      | Backup payment processor, status page monitoring  |

**Contingency Actions:**

```
IF Trial signup volume drops >30%:
├─ Review: Landing page conversion, email sequence, product onboarding
├─ Action: Refresh top 3 messages, test new audience
├─ Timeline: 2 days to implement

IF CAC increases >$35:
├─ Review: Conversion funnel (which step is leaking?)
├─ Action: A/B test landing pages, pause low-performers
├─ Timeline: Same day decision, 24-48hr implementation

IF ROAS drops <2.0x:
├─ Review: Creative fatigue, audience quality, offer clarity
├─ Action: 50% creative refresh, new audience testing
├─ Timeline: Immediate refresh
```

---

## PART 11: COMPETITIVE ADVANTAGE DOCUMENTATION

### Why Shothik Wins on Facebook vs Incumbents

| Factor                         | Incumbent (Grammarly)           | Incumbent (Quillbot)               | Shothik Advantage                                      |
| ------------------------------ | ------------------------------- | ---------------------------------- | ------------------------------------------------------ |
| **Product offer**        | Single tool (grammar)           | Single tool (paraphrase)           | Triple pillar: writing + agents + marketing            |
| **Price**                | $12/mo | $10/mo                 | $29/mo but "all-in-one" value prop |                                                        |
| **Positioning**          | Premium, established            | Affordable, specialist             | "Best of all three" + affordable                       |
| **Facebook ads message** | "Write better" (generic)        | "Rewrite faster" (generic)         | "Don't just write better — automate & market smarter" |
| **Audience resonance**   | "I need grammar help" (passive) | "I need paraphrasing" (narrow)     | "I need 10x productivity" (ambitious, inclusive)       |
| **Proof of ROI**         | Grammar improvement (soft)      | Speed improvement (soft)           | Time + money saved (hard metrics)                      |
| **Competitive moat**     | Established + brand             | Low switching cost                 | Three-pillar integration = high switching cost         |

### The Messaging Advantage

**Incumbent messaging (what they say):**

- Grammarly: "Write with confidence"
- Quillbot: "Paraphrase with accuracy"

**Shothik messaging (what you say):**

- "Write faster. Think smarter. Market better."
- "AI agents that multiply your output 10-100x"
- "One tool replaces writing software + research software + marketing automation tools"

**Why Shothik messaging wins:**

1. ✅ More ambitious (appeals to growth-minded buyers)
2. ✅ Speaks to multiple pain points (not just writing)
3. ✅ Positions as innovation (not just incremental improvement)
4. ✅ Creates bundle economics (save money + get more value)

---

## PART 12: SUCCESS MILESTONES & DECISION GATES

### 90-Day Performance Checkpoints

**30-Day Checkpoint (Month 1):**

- [ ] CAC achieves $20-30 range (or clear path to $25)
- [ ] Trial-to-paid conversion reaches 15%+ (industry baseline)
- [ ] Landing page conversion stable at 5%+ (not declining)
- [ ] Ad CTR stable at 0.9%+ (not fatiguing)
- [ ] 200-300 trial signups accumulated (or track toward goal)

- **Decision:** Continue with current messaging OR pivot (decision by Day 35)

**60-Day Checkpoint (Month 2):**

- [ ] CAC improved to $18-25 (better efficiency)
- [ ] ROAS reached 2.0x+ (breaking even or profitable)
- [ ] Trial-to-paid improved to 18%+ (optimization working)
- [ ] 600-900 trial signups accumulated (scaling working)
- [ ] Second geographic market (India) launched, metrics positive

- **Decision:** Scale budget to $20K+ OR hold budget, investigate conversion (decision by Day 65)

**90-Day Checkpoint (Month 3):**

- [ ] CAC consistent at $15-25 (sustainable unit economics)
- [ ] ROAS consistent at 2.5-3.5x (profitable at scale)
- [ ] Trial-to-paid stable at 18-25% (predictable conversion)
- [ ] 1,200-1,800 trial signups cumulatively (strong growth)
- [ ] 3-5 highest-performing creatives locked in + documented
- [ ] Creative refresh process established (avoid fatigue)

- **Decision:** Full scaling to $50K+/month (Q2 roadmap) OR investigate leaks

---

## CONCLUSION: THE FACEBOOK PLAYBOOK FOR MARKET DOMINATION

### Why This Strategy Works

**1. Differentiation Through Integration**
Most competitors own ONE pillar. Shothik owns THREE. Facebook ads can't compete on price, but they can compete on **value density** (getting writing + agents + marketing for $29 vs $50+ for competitors).

**2. Messaging Hierarchy Matches Buyer Journey**
Prospects don't know they need "agentic automation." They know they're losing 2 hours/day. The funnel guides them from problem awareness → solution awareness → Shothik preference → payment.

**3. Funnel Optimization Compounds**
Improving each step by 20-30% (landing page 7%→9%, signup 20%→25%, paid 20%→25%) reduces CAC by 40% AND scales trials by 3x. This is the leverage point.

**4. Geographic Arbitrage**
Competing in India/Southeast Asia where Grammarly/Quillbot are weak + your pricing advantage is strongest. Build here first, then expand to US.

**5. Founder Community as Moat**
The three-pillar product isn't just a feature list — it's a switching cost. Users get locked in via community (Discord, founder badge, shared wins).

---

### Implementation Priority (Next 90 Days)

**Week 1:**
✅ Land pages (3 variations, one per major audience)
✅ Core creatives (5 static, 3 video)
✅ Facebook pixel + GA4 setup

**Week 2:**
✅ Campaign launch ($2K budget, test phase)
✅ Analytics dashboard live
✅ Daily performance review process

**Week 3-4:**
✅ Performance analysis
✅ Creative refresh based on data
✅ Budget increase decision

**Month 2:**
✅ Scale to $10K budget
✅ Launch 2nd audience (lookalike)
✅ Expand geographic market (India)

**Month 3:**
✅ Scale to $20K+ budget
✅ Optimize for 2.5-3.5x ROAS
✅ Document winning creatives + messaging

---

**Document Status:** ✅ Ready for GTM team execution
**Next Review:** End of Month 1 (performance checkpoint)
**Owner:** CMO / Growth Lead
**Last Updated:** October 30, 2025
